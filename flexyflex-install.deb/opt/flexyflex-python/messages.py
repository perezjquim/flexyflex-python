ASK =		 	"Choose: "
PAUSE = 		"Press ENTER to continue."
INVALID =	"Invalid option."
EXIT = 			"Exit"
